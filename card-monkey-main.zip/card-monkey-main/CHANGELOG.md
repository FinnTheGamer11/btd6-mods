# Changelog

### v1.2.2
- Updated for Mod Helper 3.0
- Fixed Tower displays for newer BTD6
- Changed tower outline color

### Original

v0.2.1 Fix textures for BTD6 v29, remove custom tower set example

v0.2.0 Added Paragon and custom Tower Set

v0.1.3 Fixed for Bloons TD6 v28.0

v0.1.2 Support Ultimate Crosspathing

v0.1.1 Fix Display Models

v0.1.0 Pre Release